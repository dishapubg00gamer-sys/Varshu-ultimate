package com.varshu.ultimate

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selectedSeconds = 60
    private var serverOn = true
    private var busy = false
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }
    private fun params(width: Int, height: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity; x = dp(12); y = dp(180) }

    private fun showBubble() {
        val icon = ImageView(this).apply {
            setImageDrawable(android.graphics.drawable.Drawable.createFromPath(""))
            setImageResource(android.R.drawable.sym_def_app_icon)
            setBackground(bg(Color.rgb(9,35,64), 40))
            setPadding(dp(3), dp(3), dp(3), dp(3))
            // Replace generic icon with the supplied logo bitmap.
            try { setImageBitmap(android.graphics.BitmapFactory.decodeStream(assets.open("jhantu_logo.jpg"))) } catch (_: Exception) {}
            scaleType = ImageView.ScaleType.CENTER_CROP
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        // Load packaged logo from drawable resources.
        val id = resources.getIdentifier("jhantu_logo", "drawable", packageName)
        if (id != 0) icon.setImageResource(id)
        bubble = icon
        wm.addView(icon, params(dp(58), dp(58)))
        var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
        icon.setOnTouchListener { v, e ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ix=lp.x; iy=lp.y; true }
                MotionEvent.ACTION_MOVE -> { lp.x=ix+(e.rawX-sx).toInt(); lp.y=iy+(e.rawY-sy).toInt(); wm.updateViewLayout(v,lp); true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) { if(panel==null) showPanel() else hidePanel() }; true }
                else -> false
            }
        }
    }
    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(Color.rgb(9, 22, 43), 22)
        }
        val header = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            val id = resources.getIdentifier("jhantu_logo", "drawable", packageName)
            if (id != 0) setImageResource(id)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = bg(Color.WHITE, 30)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
        val heading = text("VARSHU ULTIMATE", 18f, Color.WHITE, true).apply { setPadding(dp(10),0,0,0) }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val close = text("×", 28f, Color.LTGRAY, true).apply { gravity=Gravity.CENTER; setOnClickListener { hidePanel() } }
        header.addView(close, LinearLayout.LayoutParams(dp(32), dp(42)))
        card.addView(header)
        card.addView(text("SERVER TOGGLE", 14f, Color.LTGRAY, true).apply { setPadding(0, dp(16), 0, dp(6)) })
        val toggleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        val on = Button(this).apply { text="ON"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(21,170,86)) }
        val off = Button(this).apply { text="OFF"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(90,90,90)) }
        val status = text("Demo mode", 12f, Color.LTGRAY)
        on.setOnClickListener { serverOn=true; updateToggle(on=on, off=off, status=status) }
        off.setOnClickListener { serverOn=false; updateToggle(on=on, off=off, status=status) }
        toggleRow.addView(on, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd=dp(6) })
        toggleRow.addView(off, LinearLayout.LayoutParams(0, dp(44), 1f))
        card.addView(toggleRow)
        card.addView(status.apply { setPadding(0, dp(5), 0, dp(4)) })
        card.addView(text("SELECT TIME", 14f, Color.LTGRAY, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        val times = RadioGroup(this).apply { orientation=RadioGroup.VERTICAL }
        listOf(60,120,180,300).forEach { sec ->
            val rb = RadioButton(this).apply { text="$sec seconds"; textSize=14f; setTextColor(Color.WHITE); id=sec; isChecked=sec==selectedSeconds; buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(30,190,110)) }
            times.addView(rb); rb.setOnClickListener { selectedSeconds=sec }
        }
        card.addView(times)
        val result = text("", 14f, Color.rgb(75,230,145), true).apply { gravity=Gravity.CENTER; setPadding(0, dp(8), 0, dp(6)) }
        card.addView(result)
        val start = Button(this).apply {
            text="START"
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(24,150,85))
        }
        val unfreeze = Button(this).apply {
            text="UNFREEZE"; visibility=View.GONE
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(220,65,65))
        }
        start.setOnClickListener {
            if (busy) return@setOnClickListener
            busy=true; start.isEnabled=false; result.setTextColor(Color.WHITE); result.text="Loading..."
            handler.postDelayed({
                if (panel != null) {
                    result.text = "SERVER FREEZ DONE"
                    result.setTextColor(Color.rgb(75,230,145))
                    unfreeze.visibility=View.VISIBLE
                    start.isEnabled=true
                }
                busy=false
            }, 3500)
        }
        unfreeze.setOnClickListener { result.text="UNFREEZE DONE"; unfreeze.visibility=View.GONE }
        card.addView(start, LinearLayout.LayoutParams(-1, dp(44)))
        card.addView(unfreeze, LinearLayout.LayoutParams(-1, dp(44)))
        card.addView(Button(this).apply {
            text="EXIT"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(75,85,100))
            setOnClickListener { stopSelf() }
        }, LinearLayout.LayoutParams(-1, dp(42)))
        val scroll = ScrollView(this).apply { addView(card) }
        panel = scroll
        val p = params(dp(300), dp(560))
        p.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        p.x=dp(12); p.y=dp(100)
        try { wm.addView(scroll,p) } catch (_: Exception) { panel=null }
    }
    private fun updateToggle(on: Button, off: Button, status: TextView) {
        on.setBackgroundColor(if(serverOn) Color.rgb(21,170,86) else Color.rgb(75,75,75))
        off.setBackgroundColor(if(!serverOn) Color.rgb(220,65,65) else Color.rgb(75,75,75))
        status.text = if(serverOn) "Demo toggle: ON" else "Demo toggle: OFF"
    }
    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
