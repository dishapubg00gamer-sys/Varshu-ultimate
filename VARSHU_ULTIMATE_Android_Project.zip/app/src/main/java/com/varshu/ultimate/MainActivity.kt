package com.varshu.ultimate

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(6,24,45)
        window.navigationBarColor = Color.rgb(6,24,45)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(7,19,38))
        }
        val title = TextView(this).apply {
            text = "VARSHU ULTIMATE"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Floating demo panel\nTap below to enable the floating logo."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(24))
        }
        val launch = Button(this).apply {
            text = "ENABLE FLOATING LOGO"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    finish()
                }
            }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(desc, LinearLayout.LayoutParams(-1, -2))
        root.addView(launch, LinearLayout.LayoutParams(-1, dp(54)))
        setContentView(root)
    }
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && intent.getBooleanExtra("start_overlay", false)) {
            startService(Intent(this, FloatingService::class.java))
            finish()
        }
    }
}
