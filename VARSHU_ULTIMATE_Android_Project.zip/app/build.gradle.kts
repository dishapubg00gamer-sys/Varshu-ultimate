plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.varshu.ultimate"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.varshu.ultimate"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
