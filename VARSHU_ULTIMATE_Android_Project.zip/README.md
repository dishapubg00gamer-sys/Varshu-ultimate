# VARSHU ULTIMATE — Android demo project

This is an Android Studio source project for the requested floating UI demo.

## Features
- Uses the supplied JHANTU artwork as the floating logo and panel logo.
- Floating draggable logo; tap it to open/close the panel.
- VARSHU ULTIMATE header, ON/OFF demo toggle, 60/120/180/300 second selection.
- START shows a 3.5-second loading state, then `SERVER FREEZ DONE`; UNFREEZE changes the demo status.
- EXIT stops the floating service.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle to sync (Android Gradle Plugin 8.7.3; Kotlin 2.0.21).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK. On first launch tap **ENABLE FLOATING LOGO**, then grant “Display over other apps” permission and reopen the app to enable the overlay.

Important: the freeze/unfreeze controls are UI-only demo states. They do not affect any game or server.
